# BraneMF

This is a Python implementation of BraneMF for multilayer network embedding, as described in our poster presented at ISMB/ECCB 2021 'Representaion learning in Biology (RLB) special session (pdf of poster in files):

```
python braneMF.py
```
